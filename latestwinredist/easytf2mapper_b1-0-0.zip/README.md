# easytf2_mapper
##in broken state: no. this branch is the stable release. rotation_branch is currently the development platform. It's rotations are very buggy right now.
###testing branch for rotations: rotation_branch. Check for latest updates there.
Make TF2 maps with blocks, in a sort of mario maker-esque way. currently in development; a few days or a week from being in beta. Send bugs, ideas, and suggestions to toadsrc@gmail.com.
<p>
_CURRENTLY IN ALPHA 0.1.3, functional if you have fair hammer know-how._
<p>
*READ THE README.TXT FOR INFO*

