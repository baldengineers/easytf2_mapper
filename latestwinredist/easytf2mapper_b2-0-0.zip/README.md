# Easy TF2 Mapper (beta 1.0.5)
##in broken state: YES
Make TF2 maps with blocks, in a sort of mario maker-esque way. currently in development; a few days or a week from being in beta. Send bugs, ideas, and suggestions to toadsrc@gmail.com.
### current development branch: save_branch
<p>
_CURRENTLY IN BETA 1.0.5. PROBABLY BUGGY. SEND BUGS TO toadsrc@gmail.com_
<p>
*READ THE README.TXT FOR INFO*
<p>
<p>
## to install:
[here](https://github.com/baldengineers/easytf2_mapper/wiki/Installation) is an easy instruction set for installing this.

After that, read the tutorial for more information and instructions. https://github.com/baldengineers/easytf2_mapper/wiki/Tutorial

_*BEFORE INSTALLING AND RUNNING, CHECK THE LATEST [RELEASES](https://github.com/baldengineers/easytf2_mapper/releases) FOR KNOWN BUGS*_

## bugs
A list of currently known bugs can be found here: https://github.com/baldengineers/easytf2_mapper/wiki/Currently-known-bugs
## help!
If you require assistance, first check out [the wiki](https://github.com/baldengineers/easytf2_mapper/wiki), and then try emailing the team at toadsrc@gmail.com. Responses may not be instant, but feedback is appreciated.
