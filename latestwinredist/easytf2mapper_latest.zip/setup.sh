#!/bin/bash
chmod -x linux_run.sh
sudo apt-get install wine
