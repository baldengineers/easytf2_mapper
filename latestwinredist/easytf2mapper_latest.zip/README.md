# Easy TF2 Mapper (late beta 2.6.5)
##in broken state: No.
Make TF2 maps with blocks, similar to the Time Splitters map creator. currently in development; a few weeks from release. Send bugs, ideas, and suggestions to toadsrc@gmail.com.
### current development branch: master, bugfixes
<p>
_CURRENTLY IN LATE BETA 2.6.5. PROBABLY BUGGY. SEND BUGS TO toadsrc@gmail.com_ This currently is only for Windows, but Linux compatibility is upcoming.
<p>
*READ THE README.TXT AND WIKI FOR INFO*
<p>
<p>
## to install:
[here](https://github.com/baldengineers/easytf2_mapper/wiki/Installation) is an easy instruction set for installing this.

After that, read the tutorial for more information and instructions. https://github.com/baldengineers/easytf2_mapper/wiki/Tutorial

_*BEFORE INSTALLING AND RUNNING, CHECK THE LATEST [RELEASES](https://github.com/baldengineers/easytf2_mapper/releases) FOR KNOWN BUGS*_
## screenshots:
Main window:

![Main Window](http://i.imgur.com/G7qt1Ir.jpg =437x383.5)

Main window with some prefabs added:

![Main Window With Prefabs Added In](http://i.imgur.com/1CrV0uA.jpg =437x383.5)

Inside Hammer after exporting:

![Inside Hammer After Exporting](http://i.imgur.com/Sh28kDW.png =437x383.5)

Inside TF2:

![Inside TF2 After Exporting .bsp](http://i.imgur.com/zE9KlIm.jpg =437x383.5)

![More of that](http://i.imgur.com/1xTPxxy.jpg =437x383.5)

###more screenshots can be found [here](https://github.com/baldengineers/easytf2_mapper/wiki/Screenshots)
## bugs
A list of currently known bugs can be found here: https://github.com/baldengineers/easytf2_mapper/wiki/Currently-known-bugs
## help!
If you require assistance, first check out [the wiki](https://github.com/baldengineers/easytf2_mapper/wiki), and then try emailing the team at toadsrc@gmail.com. Responses may not be instant, but feedback is appreciated.

# WARNING! UPON EXPORTING, YOU WILL HAVE TO FIX THIS BUG IF YOU USE ROTATIONS. EASILY FIXED [HERE](https://github.com/baldengineers/easytf2_mapper/wiki/Texture-bug)
