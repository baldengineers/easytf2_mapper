#!/bin/bash
sudo wine EasyTF2Mapper.exe
