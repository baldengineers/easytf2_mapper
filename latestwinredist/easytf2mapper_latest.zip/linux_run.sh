sudo apt-get install wine
sudo wine EasyTF2Mapper.exe